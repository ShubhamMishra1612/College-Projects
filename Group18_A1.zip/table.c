 #include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<unistd.h>
#include<sys/types.h>
#include<string.h>
#include<sys/wait.h>
#include<sys/ipc.h>
#include<sys/shm.h>


#define Buff_Size  25
#define read_end 0
#define write_end 1
#define size 20
typedef struct
{
  int Order[5][20];
  int numCustomer;
  int count[5];
  bool initTermination;
  bool isValid;
  bool Validated;
  bool restart;
  bool OrderTaken;
  int TableSum;
  int totalAmount;
}Data;

typedef struct
{
  int choice[20];
  int num;
}Selection;


//function to Display Menu
void ShowMenu()
{

  printf("MENU:-\n");
  FILE *ptr;
  char c;
  ptr = fopen("menu.txt","r");
  while(c!=EOF){
      c = fgetc(ptr);
      printf("%c",c);
    
    }
    
    fclose(ptr);
}

int GetTableSum(int *arr,int len)
{
   int sum =0;
   for(int i=0;i<len;i++)
   {
     sum += arr[i];
   }
   
   return sum;
}



int main()
{
  int TableNumber;
  printf("Enter Table no.: ");
  scanf("%d",&TableNumber);
  
  char Tcode = TableNumber + 65;
  
  key_t key; //generating the key
  if((key = ftok("table.c", Tcode))==-1){ 
		perror("Error in ftok\n");
		return 1;
	}
	
  int shmID;
  Data *shmPtr;
  
  shmID = shmget(key,sizeof(Data),0666 | IPC_CREAT);
  
  shmPtr = (Data*)shmat(shmID,NULL,0);   
  
  
  int order[20];
  int index = 0;
  
 while(1)
 {
 
  shmPtr->OrderTaken = false;
  int numCustomer;
  printf("\nEnter Number of Customers at Table (maximum no. of customers can be 5): ");
  scanf("%d",&numCustomer);
  
  shmPtr->numCustomer = numCustomer;
  shmPtr->initTermination = false;
  
  ShowMenu(); //printing Menu to screen
  
    Selection read_msg;
    Selection odr;
  
    if(shmPtr==(void*)-1)        
    {  
     printf("Could Not Create Shared Memeory.....\n");
     return 0;         
    }            
            
            
  
  
  int start = 0;
  
 
 while(1)
 {
  shmPtr->OrderTaken = false;
  
  for(int i =0;i<numCustomer;i++)
  {
    int arr[2];
    if(pipe(arr)==-1)
    {
      printf("Pipe Failure\n");
      return 0;
    }
    
    pid_t pid = fork(); //creating child process : Customer
    
    if(pid<0 ){
     printf("fork error has occurred\n");
     return 0;
    }
    else if(pid==0)
    {  
       printf("Order for Customer %d: - \n",i+1);
       
       close(arr[read_end]);  //implementing ordinary pipe
       
       
       int ch;
       start =0;
       printf("Enter the serial number(s) of the item(s) to order from the menu. Enter -1 when done: ");
       do
       {
          
          scanf("%d",&ch);
          
          if(ch!=-1)
          {
             odr.choice[start++] = ch;
          }
          
        
       }while(ch!=-1);
       odr.num = start;
       write(arr[write_end],&odr,sizeof(Selection));  //writing into the pipe
       close(arr[write_end]);
       return 0;
      
    }
    else{
            wait(NULL);
            
            close(arr[write_end]);
            
            read(arr[read_end],&read_msg,sizeof(Selection));  //parent reading order from pipe
          
           for(int j =0;j<read_msg.num;j++)
           {
             shmPtr->Order[i][j] = read_msg.choice[j];
             shmPtr->count[i] = read_msg.num;
             
           }
            
            close(arr[read_end]);
            
       }
   }
   shmPtr->OrderTaken = true;
  
  while(1)
  {
  
   if(shmPtr->Validated == true)
   {
      break;
    
   }
   
  }

   
   if(shmPtr->isValid == true)  
      break;
   else{
         
         shmPtr->OrderTaken = false;
        }
   
 }
    
    printf("\nTotal Bill Amount: %d",shmPtr->totalAmount);
    order[index++] =  shmPtr->totalAmount;
    int res;
    printf("\nSeat a new set of Customers(1/-1): ");
    scanf("%d",&res);  
   
    if(res==-1){
      shmPtr->TableSum = GetTableSum(order,index);
      shmPtr->restart = false;
      shmPtr->initTermination = true;
      break;
     }
     else{
        shmPtr->restart = true;
        shmPtr->initTermination = false;
         shmPtr->OrderTaken = false;
        }
     
     printf("\n%d",shmPtr->restart);
   
  }
   
   
  
   
  shmdt(shmPtr);
            
           
  
  return 0;
}
